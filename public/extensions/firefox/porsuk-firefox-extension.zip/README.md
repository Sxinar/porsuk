# Porsuk Extension - Firefox

## Kurulum
1. `about:debugging#/runtime/this-firefox` açın.
2. `Load Temporary Add-on` seçin.
3. Bu klasörden `manifest.json` dosyasını seçin.
4. Uzantı ayarından Porsuk adresini girin.

Not: Geçici yükleme, tarayıcı yeniden başlayınca sıfırlanır.

## Kullanım
- Sayfada sağ tık -> `Porsuk ile Oku`
- Ya da uzantı ikonuna tıkla
